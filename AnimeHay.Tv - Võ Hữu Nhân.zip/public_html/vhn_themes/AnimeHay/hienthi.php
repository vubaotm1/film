              <?php
 $result = mysqli_query($ketnoi,"SELECT * FROM vhn_film ORDER BY id DESC");
                if($result)
                {
                while($row = mysqli_fetch_assoc($result))
                {
				?>
				<?php $tap = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `vhn_tap` WHERE `linkphim` = '".$row['linkphim']."' "));  ?>
	<div class="ah-col-film" data-id="<?php echo $row['id'] ?>">
				<div class="ah-pad-film">
					<div class="ah-effect-film"><a href="https://aniraw.net/Info/<?php echo $row['linkphim'] ?>"></a></div>
					<a href="https://aniraw.net/Info/<?php echo $row['linkphim'] ?>">
						<img src="<?php echo $row['thumbnail'] ?>"/>
						<span class="number-ep-film">
						<?php echo $tap; ?>/<?php echo $row['tongsotap'] ?></span>
						<?php if($row['loaiphim'] == 'phimbo'){
					echo '<span class="rate-point">HD</span>';
					} ?>
					<?php if($row['loaiphim'] == 'phimle'){
					echo '<span class="rate-point">Phim lẻ</span>';
					} ?>
						<span class="name-film"><?php echo $row['tenphim'] ?></span>
					</a>
				</div>
			</div>
			<?php
				}}
			?>