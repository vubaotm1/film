<!DOCTYPE html>
<html lang="vi">
<?php
$ketqua = $_GET['ketqua'];
require("./vhn_config.php");
echo '<title>Kết quả tìm kiếm cho : '.$ketqua.'</title>';
include ("head.html"); ?>
<body>
<div id="ah-wrapper">
<?php include ("header.html"); ?>
    <div id="ah-container" class="ah-clear-both">	<div>
	
	</div>
	<div class="ah-row-film ah-clear-both">
		<div class="ah-head-film">
			<span class="tab-one active-tab"><i class="fa fa-star-half-o" aria-hidden="true"></i> Kết quả tìm kiếm cho : <?php echo $ketqua ?></span>
			<span id="refresh-film-home" onClick="refreshFilmhome()" time="1553830534" class="refresh-film-home"><i class="fa fa-refresh"></i></span>
			</div>
   <?php
 $con = mysql_connect (LOCALHOST,USERNAME,PASSWORD);
 mysql_select_db (DATABASE, $con);

  if (!$con)
    { 
    die ("Could not connect: " . mysql_error());
    } 
    $sql = mysql_query("SELECT * FROM vhn_film WHERE tenphim LIKE '%$ketqua%'") or die
        (mysql_error());

       while ($row = mysql_fetch_array($sql)){
           $tap = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `vhn_tap` WHERE `linkphim` = '".$row['linkphim']."' "));
    ?>
    <?php echo '<div class="ah-col-film" data-id="1">
				<div class="ah-pad-film">
					<div class="ah-effect-film"><a href="'.$trangchu.'/Info/'.$row['linkphim'].'"></a></div>
					<a href="https://aniraw.net/Info/'.$row['linkphim'].'">
						<img src="'.$row['thumbnail'].'">
						<span class="number-ep-film">
						'.$tap.'/'.$row['tongsotap'].'</span>
						<span class="rate-point">HD</span>											<span class="name-film">'.$row['tenphim'].'</span>
					</a>
				</div>
			</div>' ?>
    <?php
  }

  mysql_close($con)
   ?>
   	</div>
   	<?php include ("footer.html"); ?>
</div>
</div>
</body>
</html>