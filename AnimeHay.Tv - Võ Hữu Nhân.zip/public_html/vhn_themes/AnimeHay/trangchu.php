<!DOCTYPE html>
<html lang="vi">
<?php
require("./vhn_config.php");
include ("head.html"); ?>
<body>
    <style>
        
      <style>
      body {
	font-family: 'Roboto', sans-serif;
	font-size: 14px;
	line-height: 18px;
	background: #f4f4f4;
}

.list-wrapper {
	padding: 15px;
	overflow: hidden;
}

..ah-col-film {
	border: 1px solid #EEE;
	background: #FFF;
	margin-bottom: 10px;
	padding: 10px;
	box-shadow: 0px 0px 10px 0px #EEE;
}

..ah-col-film h4 {
	color: #FF7182;
	font-size: 18px;
	margin: 0 0 5px;	
}

..ah-col-film p {
	margin: 0;
}

.simple-pagination ul {
	margin: 0 0 20px;
	padding: 0;
	list-style: none;
	text-align: center;
}

.simple-pagination li {
	display: inline-block;
	margin-right: 5px;
}

.simple-pagination li a,
.simple-pagination li span {
	color: #666;
	padding: 5px 10px;
	text-decoration: none;
	border: 1px solid #EEE;
	background-color: #FFF;
}

.simple-pagination .current {
	color: #FFF;
	background-color: #FF7182;
	border-color: #FF7182;
}

.simple-pagination .prev.current,
.simple-pagination .next.current {
	background: #e04e60;
}
    </style>

  <script>
  window.console = window.console || function(t) {};
</script>

  
  
  <script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }
</script>
    </style>
<div id="ah-wrapper">
<?php include ("header.html"); ?>
    <div id="ah-container" class="ah-clear-both">	<div>
		<div class="ah-scroll-fnom">
			<?php include ("moicapnhat.php");?>
			</div>
	</div>
	<div class="ah-row-film ah-clear-both">
		<div class="ah-head-film">
			<span class="tab-one active-tab"><i class="fa fa-star-half-o" aria-hidden="true"></i> Phim mới cập nhật</span>
		
		
		</div>  <div class="list-wrapper">

									<?php include ("hienthi.php"); ?>
							
			</div>	</div>
			
<div id="pagination-container"></div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/simplePagination.js/1.6/jquery.simplePagination.js'></script>

    <script id="rendered-js" >
      // jQuery Plugin: http://flaviusmatis.github.io/simplePagination.js/

var items = $(".list-wrapper .ah-col-film");
var numItems = items.length;
var perPage = 20;

items.slice(perPage).hide();

$('#pagination-container').pagination({
  items: numItems,
  itemsOnPage: perPage,
  prevText: "&laquo;",
  nextText: "&raquo;",
  onPageClick: function (pageNumber) {
    var showFrom = perPage * (pageNumber - 1);
    var showTo = showFrom + perPage;
    items.hide().slice(showFrom, showTo).show();
  } });
      //# sourceURL=pen.js
    </script>


	
	<?php include ("footer.html"); ?>
</div>
</div>
</body>
</html>