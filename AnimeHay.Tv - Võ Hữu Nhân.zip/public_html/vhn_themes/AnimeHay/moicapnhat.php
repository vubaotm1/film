
<div class="ah-clear-both ah-home-fnom">
                  <?php
 $result = mysqli_query($ketnoi,"SELECT * FROM vhn_film ORDER BY luotxem DESC limit 0,10");
                if($result)
                {
                while($row = mysqli_fetch_assoc($result))
                {
				?>
				<?php $tap = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `vhn_tap` WHERE `linkphim` = '".$row['linkphim']."' "));  ?>
															<div class="ah-col-film">
							<div class="ah-pad-film">
								<div class="ah-effect-film"><a href="https://aniraw.net/Info/<?php echo $row['linkphim'] ?>"></div>
								<a href="https://aniraw.net/Info/<?php echo $row['linkphim'] ?>">
									<img src="<?php echo "".$row["anhbia"].""; ?>"/>
									<span class="number-ep-film">
									<?php echo $tap ?>									</span>
									<span class="name-film"><span><?php echo "".$row["tenphim"].""; ?></span><span><?php echo "".$row["namphim"].""; ?></span></span>
								</a>
							</div>
						</div>
	<?php
				}}
			?>