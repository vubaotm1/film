<?php 
session_start();
require ("../vhn_config.php");
require ("../vhn_themes/AnimeHay/head.html");?>
<?php
include("head.php");
include("menu.php");
?>
<?php if (isset($_SESSION['user_id'])) { ?>
<style>
    .VHN-control{
    background: #a3a3a3;
    color: #fff;
    padding: 5px;
    font-size: 13px;}
</style>
<div class="main">

			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
	<div class="row">

		<div class="col-md-12">

			<!-- CONDENSED TABLE -->
			<div class="panel">
				<div class="panel-heading">
					<h3 class="panel-title">Quản lý phim</h3>
				</div>
				<div class="panel-body">
					<table class="table table-condensed">
						<thead>
							<tr><th>ID</th><th>Tên phim</th><th>Tổng số tập</th><th>Lượt xem</th><th>Quản lý</th></tr>
						</thead>
						<tbody>
						                  <?php
 $result = mysqli_query($ketnoi,"SELECT * FROM vhn_film ORDER BY luotxem DESC");
                if($result)
                {
                while($row = mysqli_fetch_assoc($result))
                {
				?>
							<tr>
							    <td><?php echo $row['id'] ?></td>
							    <td><?php echo $row['tenphim'] ?></td>
							    <td><?php echo $row['tongsotap'] ?></td>
							    <td><?php echo $row['luotxem'] ?></td>
							    <td><a class="VHN-control" href="ThemTapPhim?VHN=<?php echo $row['linkphim'] ?>"><i class="fa fa-plus" aria-hidden="true"></i></a>
							    <a class="VHN-control" href="EditPhim?VHN=<?php echo $row['linkphim'] ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
							    <a class="VHN-control" onclick="if (confirm('Bạn có chắc chắc muốn xóa phim <?php echo "".$row["tenphim"].""; ?>?')) window.location.href='Xoa.php?VHN=<?php echo $row['linkphim'] ?>';" ><i class="fa fa-trash" aria-hidden="true"></i></a>
</a></td>
							    </tr>
							<?php }} ?>
						</tbody>
					</table>
				</div>
			</div>
			<!-- END CONDENSED TABLE -->

		</div>
	</div>
	

				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
  <?php
include("js.php");
?>

</body>

</html>
<?php } ?>