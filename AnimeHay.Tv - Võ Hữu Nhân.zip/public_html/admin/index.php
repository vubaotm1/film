<?php
session_start();
require("../vhn_config.php");
include("head.php");
?>
<?php if (isset($_SESSION['user_id'])) { ?>
<?php include("menu.php"); ?>
<div class="main">

			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<h3 class="panel-title">Thống kê Website</h3>
							<p class="panel-subtitle">Thống kê Website chi tiết</p>
						</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-download"></i></span>
										<p>
											<span class="number"><?php $cmt = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `vhn_film` "));  echo number_format(" $cmt;") ?></span>
											<span class="title">Số phim</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-shopping-bag"></i></span>
										<p>
											<span class="number"><?php $cmt = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `vhn_tap` "));  echo number_format(" $cmt;") ?></span>
											<span class="title">Số tập</span>
										</p>
									</div>
								</div>
								<!--<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-eye"></i></span>
										<p>
											<span class="number">274,678</span>
											<span class="title">Visits</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-bar-chart"></i></span>
										<p>
											<span class="number">35%</span>
											<span class="title">Conversions</span>
										</p>
									</div>
								</div>-->
							</div>

					
						</div>
					</div>
					<!-- END OVERVIEW -->

				
					<div class="row">
						<div class="col-md-7">
							<!-- TODO LIST -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">TOP 3 XEM NHIỀU</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										<button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<ul class="list-unstyled todo-list">
									    <?php
				$result = mysqli_query($ketnoi,"SELECT * FROM vhn_film ORDER BY luotxem DESC limit 0,3");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
										<li>
											<label class="control-inline fancy-checkbox">
												<input type="checkbox"><span></span>
											</label>
											<p>
												<span class="title"><?php echo "".$row["tenphim"].""; ?></span>
												<span style="-webkit-line-clamp: 2; -webkit-box-orient: vertical;overflow: hidden;text-overflow: ellipsis; display: -webkit-box;max-height: 52px" class="short-description"><?php echo "".$row["noidung"].""; ?></span>
												<span class="date"><?php echo "".$row["luotxem"].""; ?> Lượt xem</span>
											</p>
											<div class="controls">
												<a href="#"><i class="icon-software icon-software-pencil"></i></a> <a href="#"><i class="icon-arrows icon-arrows-circle-remove"></i></a>
											</div>
										</li>
										           	<?php 
				}
				}
				?>
									</ul>
								</div>
							</div>
							<!-- END TODO LIST -->
						</div>
						<div class="col-md-5">
							<!-- TIMELINE -->
							<div class="panel panel-scrolling">
								<div class="panel-heading">
									<h3 class="panel-title">Recent User Activity</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										<button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
									</div>
								</div>
								<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 430px;"><div class="panel-body" style="overflow: hidden; width: auto; height: 430px;">
									<ul class="list-unstyled activity-list">
										<li>
											<img src="assets/img/user1.png" alt="Avatar" class="img-circle pull-left avatar">
											<p><a href="#">Michael</a> has achieved 80% of his completed tasks <span class="timestamp">20 minutes ago</span></p>
										</li>
										<li>
											<img src="assets/img/user2.png" alt="Avatar" class="img-circle pull-left avatar">
											<p><a href="#">Daniel</a> has been added as a team member to project <a href="#">System Update</a> <span class="timestamp">Yesterday</span></p>
										</li>
										<li>
											<img src="assets/img/user3.png" alt="Avatar" class="img-circle pull-left avatar">
											<p><a href="#">Martha</a> created a new heatmap view <a href="#">Landing Page</a> <span class="timestamp">2 days ago</span></p>
										</li>
										<li>
											<img src="assets/img/user4.png" alt="Avatar" class="img-circle pull-left avatar">
											<p><a href="#">Jane</a> has completed all of the tasks <span class="timestamp">2 days ago</span></p>
										</li>
										<li>
											<img src="assets/img/user5.png" alt="Avatar" class="img-circle pull-left avatar">
											<p><a href="#">Jason</a> started a discussion about <a href="#">Weekly Meeting</a> <span class="timestamp">3 days ago</span></p>
										</li>
									</ul>
									<button type="button" class="btn btn-primary btn-bottom center-block">Load More</button>
								</div><div class="slimScrollBar" style="background: rgb(0, 0, 0); width: 7px; position: absolute; top: 0px; opacity: 0.4; display: block; border-radius: 7px; z-index: 99; right: 1px; height: 288.456px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
							</div>
							<!-- END TIMELINE -->
						</div>
					</div>
				


				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
<?php } else {  ?>
<style>
    .auth-box .left {
    float: left;
    width: 100%;
    height: 100%;
    padding: 0 30px;
    text-align: center;
}
body {
    background-color: #F3F5F8;
    font-family: Roboto;
    font-size: 15px;
    color: #676a6d;
}
.auth-box {
    -moz-box-shadow: 1px 2px 10px 0 rgba(0, 0, 0, 0.1);
    -webkit-box-shadow: 1px 2px 10px 0 rgba(0, 0, 0, 0.1);
    box-shadow: 1px 2px 10px 0 rgba(0, 0, 0, 0.1);
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
    width: 40%;
    height: 450px;
    margin: 0 auto;
    ba
</style>
<body>
	<div id="wrapper">
		<div class="vertical-align-wrap">
			<div class="vertical-align-middle">
				<div class="auth-box ">
					<div class="left">
						<div class="content">
							<div class="header">
								<div class="logo text-center"><img src="assets/img/logo-dark.png" alt="Klorofil Logo"></div>
								<p class="lead">Đăng nhập quản lý</p>
							</div>
							<form class="form-auth-small" action="" method="post">
								<div class="form-group">
									<label for="signin-email" class="control-label sr-only">Tài khoản</label>
									<input type="text" class="form-control" name="taikhoan" placeholder="Tài khoản">
								</div>
								<div class="form-group">
									<label for="signin-password" class="control-label sr-only">Mật khẩu</label>
									<input type="password" class="form-control" name="matkhau" placeholder="Mật khẩu">
								</div>
								<div class="form-group clearfix">
									<label class="fancy-checkbox element-left">
										<input type="checkbox">
										<span>Remember me</span>
									</label>
								</div>
								<button name="login" type="submit" class="btn btn-primary btn-lg btn-block">ĐĂNG NHẬP</button>
								
							</form>
							<?php 
			  if(isset($_POST['login']))
{
ob_start();
include_once("../vhn_config.php");
session_start();
if(isset($_SESSION['user_id'])!="") {
	header("Location: index.php");
}
if (isset($_POST['login'])) {
	$taikhoan = mysqli_real_escape_string($conn, $_POST['taikhoan']);
	$matkhau = mysqli_real_escape_string($conn, $_POST['matkhau']);
	$result = mysqli_query($conn, "SELECT * FROM vhn_admin WHERE taikhoan = '" . $taikhoan. "' and matkhau = '$matkhau'");
	if ($row = mysqli_fetch_array($result)) {
		$_SESSION['user_id'] = $row['id'];
		$_SESSION['user_name'] = $row['taikhoan'];	
		echo '<div id="toast-container" class="toast-top-right"><div class="toast toast-success" aria-live="polite" style="display: block;"><button type="button" class="toast-close-button" role="button">×</button><div class="toast-message">Pass đúng, vui lòng đợi 3 giây</div></div></div>';
		header("Refresh:3; index.php");
	} else {
		echo '<div id="toast-container" class="toast-top-right"><div class="toast toast-error" aria-live="assertive" style="display: block;"><button type="button" class="toast-close-button" role="button">×</button><div class="toast-message">Sai mật khẩu</div></div></div>';
	}}
}}
?>
						</div>
					</div>
				
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	</body>
<?php
include("js.php");
?>
