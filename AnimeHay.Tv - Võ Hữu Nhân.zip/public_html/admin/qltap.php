<?php 
session_start();
require ("../vhn_config.php");
require ("../vhn_themes/AnimeHay/head.html");?>
<?php
include("head.php");
include("menu.php");
$VHN = $_GET['VHN'];
?>
<?php if (isset($_SESSION['user_id'])) { ?>


<style>
    .btn-primary {
    background-color: #434c78;
    border-color: #434c78;
}
</style>
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
				
					<div class="row">
					
						<div class="col-md-12">
							<!-- LABELS -->

							<!-- INPUT GROUPS -->
	<?php $tap = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `vhn_tap` WHERE `linkphim` = '$VHN' "));  ?>
							<?php
$sql4 = "SELECT * FROM vhn_film WHERE linkphim = '$VHN'";
if($result1 = mysqli_query($ketnoi, $sql4)){
    if(mysqli_num_rows($result1) > 0){
        while($row = mysqli_fetch_array($result1)){
            ?>
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Chỉnh sửa phim <?php echo $row['tenphim'] ; ?> (<?php echo $tap ?>/<?php echo $row['tongsotap'] ?> tập)</h3>
								</div>
								<div class="panel-body">
								    <form action="" method="post">
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-user"></i></span>
										<input class="form-control" placeholder="Tên phim" value="<?php echo $row['tenphim'] ?>" type="text" name="tenphim"   required>
									</div><br/>
	<div class="input-group" style="width: 100%;">
									<textarea class="form-control" name="mota" placeholder="Nội dung, mô tả của phim" rows="5" required><?php echo $row['noidung'] ?></textarea>
									</div><br/>
									<button type="submit" name="save" class="btn btn-primary btn-block">Sửa phim</button>
									</form>
								</div>
							</div>
							<!-- END INPUT GROUPS -->
						
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
	
							<?php
if(isset($_POST['save']))
{
$tenphim = mysqli_real_escape_string($link, $_REQUEST['tenphim']);
$mota = mysqli_real_escape_string($link, $_REQUEST['mota']);
    $sql = "UPDATE `vhn_film` SET `tenphim` = N'".$tenphim."',`noidung` = N'".$mota."' WHERE linkphim = '$VHN'";
mysql_query("set names 'utf-8'");
if(mysqli_query($link, $sql)){
header("Refresh:0; url=EditPhim?VHN=$VHN");
    header("Refresh:0");

} else{
header("Refresh:0; url=EditPhim?VHN=$VHN");
    header("Refresh:0");

}

}

?>
  <?php
include("js.php");
?>
       

</body>

</html>
<?php }}}} ?>