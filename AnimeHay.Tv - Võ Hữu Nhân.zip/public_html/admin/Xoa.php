<?php
header('Content-Type: text/html;charset=utf-8');  
ob_start();
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
if((isset($_GET['VHN']))){
    $VHN = $_GET['VHN'];
    
?>
<?php
include('../vhn_config.php');
// sql to delete a record
$sql = "DELETE FROM vhn_film WHERE linkphim='$VHN';";
if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
    header('Location: QuanLy');
exit;
} else {
    echo "Xóa không thành công, lỗi : " . $conn->error;
}
$sql1 = "DELETE FROM vhn_tap WHERE linkphim='$VHN';";
if ($conn->query($sql1) === TRUE) {
    echo "Record deleted successfully";
    header('Location: QuanLy');
exit;
} else {
    echo "Xóa không thành công, lỗi : " . $conn->error;
}

$conn->close();}

?>