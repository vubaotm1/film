<?php 
session_start();
require ("../vhn_config.php");
require ("../vhn_themes/AnimeHay/head.html");?>
<?php
include("head.php");
include("menu.php");
$VHN = $_GET['VHN'];
?>
<?php if (isset($_SESSION['user_id'])) { ?>


<style>
    .btn-primary {
    background-color: #434c78;
    border-color: #434c78;
}
</style>
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
				
					<div class="row">
					
						<div class="col-md-12">
							<!-- LABELS -->

							<!-- INPUT GROUPS -->
	<?php $tap = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `vhn_tap` WHERE `linkphim` = '$VHN' "));  ?>
							<?php
$sql4 = "SELECT * FROM vhn_film WHERE linkphim = '$VHN'";
if($result1 = mysqli_query($ketnoi, $sql4)){
    if(mysqli_num_rows($result1) > 0){
        while($row = mysqli_fetch_array($result1)){
            ?>
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Thêm tập vào bộ <?php echo $row['tenphim'] ; ?> (<?php echo $tap ?>/<?php echo $row['tongsotap'] ?>)</h3>
								</div>
								<div class="panel-body">
								    <form action="" method="post">
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-user"></i></span>
										<input class="form-control" placeholder="Ví dụ 1, OVA" type="text" name="sotap"   required>
									</div><br/>
										<div style="display:none" class="input-group">
										<span class="input-group-addon"><i class="fa fa-user"></i></span>
										<input class="form-control" placeholder="Ví dụ 1, OVA" type="text" value="<?php echo $row['linkphim'] ; ?>" name="linkphim"   required>
									</div>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-photo"></i></span>
										<input class="form-control" placeholder="Player (Google Drive)" type="text" id="sharelink"   required>
									</div><br/>
									<div style="display:none" class="input-group">
										<span class="input-group-addon"><i class="fa fa-link"></i></span>
										<input class="form-control" placeholder="Player (Google Drive)" type="text" id="player" name="player"  required>
									</div>
									<button type="submit" name="save" class="btn btn-primary btn-block">Thêm phim</button>
									</form>
								</div>
							</div>
							<!-- END INPUT GROUPS -->
						
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		 <script id="rendered-js">
          (function ($) {
  $(function () {
    var $shareLink = $('#sharelink'),
    $player = $('#player'),
    $copyButton = $('#copylinkbtn'),
    clipboard;

    $shareLink.on('keyup paste', function () {
      var link = $shareLink.val(),
      l = link.replace(/https?:\/\/drive.google.com\/file\/d\/(.+)\/(.+)/, "$1");
      if (l !== link) {
        $player.val(l);
        $copyButton.removeAttr('disabled');
      } else {
        $player.val('');
        $copyButton.attr('disabled', 'disabled');
      }
    });

    $player.on('click', function () {
      $player.select();
    });

    clipboard = new Clipboard('#copylinkbtn');
    clipboard.on('success', function (e) {
      $.notify({
        icon: 'glyphicon glyphicon-ok-circle',
        title: 'Link copied to clipboard:',
        message: e.text,
        url: e.text,
        target: '_blank' },
      {
        // settings
        type: "success",
        placement: {
          from: "top",
          align: "center" } });



      // $.notify(e.text + " copied to clipboard.");

      e.clearSelection();
    });

  });
})(jQuery);
          //# sourceURL=pen.js
        </script>
							<?php
if(isset($_POST['save']))
{
$linkphim = mysqli_real_escape_string($link, $_REQUEST['linkphim']);
$sotap = mysqli_real_escape_string($link, $_REQUEST['sotap']);
$player = mysqli_real_escape_string($link, $_REQUEST['player']);
$sql = "INSERT INTO vhn_tap (sotap, player, linkphim) VALUES (N'$sotap', '$player', '$linkphim')";
mysql_query("set names 'utf-8'");
if(mysqli_query($link, $sql)){
    echo "<script>alert('Thành công!');</script>";
} else{
    echo "<script>alert('Thất bại!');</script>";
}

}

?>
  <?php
include("js.php");
?>
       

</body>

</html>
<?php }}}} ?>